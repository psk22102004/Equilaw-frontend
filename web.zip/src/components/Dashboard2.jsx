import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import CaseCarousel from './CaseCarousel';
import { PlusCircle } from 'lucide-react';


const Dashboard2 = () => {
    const navigate = useNavigate();

    const features = [
        { imgSrc: '/pendingCases.png', title: 'Pending Cases', value: '12' },
        { imgSrc: '/agreement.png', title: 'Completed Cases', value: '50' },
        { imgSrc: '/income.png', title: 'Income', value: 'Rs. 5 Cr' },
    ]

    const [casesData, setCasesData] = useState([
        { caseid: 1, title: 'Vijay Balwant Badhan Vs C And M m Ltd', category: 'Land Dispute', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'open' },
        { caseid: 2, title: 'Vijay Balwant Badhan Vs C And M Farming Ltd', category: 'Contract Breach', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'open' },
        { caseid: 3, title: 'Shankar Jodharam Sangtani Vs Radheya forging pvtltd', category: 'Financial Fraud', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'open' },
        { caseid: 4, title: 'Case 4', category: 'Category 1', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'open' },
        { caseid: 5, title: 'Salah is underrated', category: 'Category 1', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'closed' },
        { caseid: 6, title: 'The State vs PSK', category: 'Land Dispute', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'closed' },
        { caseid: 7, title: 'Case 5', category: 'Category 1', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'closed' },
        { caseid: 8, title: 'Case 5', category: 'Category 1', issue_date: '2021-01-01', description: ' This is some random description to show on the case card . It will serve as short and crisp idea about the case', status: 'closed' },
    ]);

    //useEffect to fetch all cases data from backend
    // useEffect(
    //     ()=>{
    //         const fetchCases = async()=>{
    //             const response = await axios.get('http://localhost:8000/cases/get_all_cases');
    //             console.log('fetched cases are : ',response.data); //cases fetched , now set them in setCasesData
    //             //response.data is also an array of objects , so you need to spread it , if u want to include the example cases as well. If you directly wanna replace it then just use response.data
    //             setCasesData(
    //                 (prev)=>{
    //                     return ([...prev , ...response.data])
    //                 }
    //             )
    //         }
    //         fetchCases();
    //     } , []
    // )

    const openCases = casesData.filter(caseItem => caseItem.status === 'open');
    const closedCases = casesData.filter(caseItem => caseItem.status === 'closed')


    return (
        <div className=" flex-1 h-screen ">
            <main className=" p-8 overflow-auto space-y-12 bg-elephant-50 text-black">

                {/* WELCOME TITLE STARTS */}
                <div className='welcomeTitle  flex justify-between '>
                    <div className='greetingBox border flex flex-col w-full mx-auto relative space-y-4 p-8  rounded-xl bg-gradient-to-r from-[white] via-elephant-200  to-elephant-900 '>
                        <h1 className='text-3xl font-semibold  '>Good Morning !</h1>
                        <h1 className='text-4xl font-bold  '>Parth Kadam</h1>

                        {/* <img className='h-60 w-60 absolute right-12 bottom-0 ' src='/doctorIllustration.png' /> */}
                        <img className='md:w-96 absolute right-0 md:right-20 bottom-0  ' src='/lawyerIllustration.png' />
                    </div>
                </div>
                {/* WELCOME TITLE ENDS */}

                {/* STATISTICS CARDS START */}
                <div className='statisticCardBox grid grid-cols-12  space-x-6'>
                    {
                        features.map(
                            (ele, index) => (
                                <div className='feature border-2 border-elephant-900 bg-white col-span-12 md:col-span-4   p-6 flex  space-x-10 rounded-xl '>
                                    <img src={ele.imgSrc} className='h-20 w-20 rounded-full border border-elephant-950   bg-white p-1 ' />
                                    <div className='flex flex-col space-y-3 '>
                                        <p className=' text-xl font-semibold'>{ele.title}</p>
                                        <h1 className=' font-bold text-3xl'> {ele.value} </h1>
                                    </div>
                                </div>
                            )
                        )
                    }
                </div>
                {/* STATISTICS CARDS END */}


                {/* Pending CASES START */}
                <div className='flex flex-col  px-1 '>
                    <div className='flex justify-between'>
                        <h1 className='text-3xl font-semibold'>Pending Cases</h1>
                        <button className='border border-black bg-elephant-800 hover:bg-elephant-950 text-white font-semibold px-8 py-2 rounded-xl' onClick={() => navigate('/user/addCase')}>  Add case </button>
                    </div>
                    <div className='caseCarousel flex '>
                        <CaseCarousel cardData={openCases} />
                    </div>
                </div>
                {/* Pending CASES END */}

                {/* CLOSED CASES START */}
                <div className='flex flex-col  px-1 '>
                    <h1 className='text-3xl font-semibold'>Closed Cases</h1>
                    <div className='caseCarousel flex '>
                        <CaseCarousel cardData={closedCases} />
                    </div>
                </div>
                {/* CLOSED CASES END */}
            </main>
        </div>
    )
}

export default Dashboard2