import React from 'react'

const DocGenerate = () => {
  return (
    <div>DocGenerate</div>
  )
}

export default DocGenerate