import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
function Navbar(props) {
    const navigate = useNavigate();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const handleClick = () => {
        navigate('/user');
    }
    return (
        <div className="flex justify-between items-center align-middle py-3  md:py-5 px-9 mt-5  rounded-full shadow shadow-gray-400">
            <h1 className=" text-lg md:text-2xl font-semibold font-playfair
             ">{props.title}</h1>
            <div className="flex gap-8 ">
                <ul className="hidden md:flex">
                    <li className="flex gap-8 py-2.5 font-semibold text-black">
                        <a href="#" className="hover:text-elebtn ">{props.navitem1}</a>
                        <a href="#" className="hover:text-elebtn ">{props.navitem2}</a>
                        <a href="#" className="hover:text-elebtn ">{props.navitem3}</a>
                        <a href="#" className="hover:text-elebtn ">{props.navitem4}</a>
                        <a href="#" className="hover:text-elebtn ">{props.navitem5}</a>
                    </li>
                </ul>


                <div className="md:hidden " ><box-icon name='menu' color='#000aff' onClick={() => setIsMenuOpen(!isMenuOpen)} ></box-icon></div>
                <div className={`absolute md:hidden top-32 left-0 w-full bg-white flex flex-col p-3 shadow items-center gap-6 font-semibold transform transition-transform ${isMenuOpen ? "opacity-100" : "opacity-0"}`} >
                    <a href="#" className=" rounded p-2 hover:bg-blue-200 hover:text-black w-full">{props.navitem1}</a>
                    <a href="#" className=" rounded p-2 hover:bg-blue-200  hover:text-black w-full">{props.navitem2}</a>
                    <a href="#" className=" rounded p-2 hover:bg-blue-200  hover:text-black w-full">{props.navitem3}</a>
                    <a href="#" className=" rounded p-2 hover:bg-blue-200  hover:text-black w-full">{props.navitem4}</a>
                    <a href="#" className=" rounded p-2 hover:bg-blue-200  hover:text-black w-full">{props.navitem5}</a>
                    <a href="#" onClick={handleClick} className="rounded p-2 hover:bg-blue-700 hover:text-white w-full ">{props.button}</a>

                </div>
            </div>

            <button onClick={handleClick} className="bg-elebtn active:bg-blue-600 text-white hidden md:block py-2.5 px-5 font-semibold rounded-2xl shadow ">{props.button}</button>


        </div>
    );
}
export default Navbar;