import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { Plus, FileText, Trash2, Eye } from 'lucide-react';
import { Modal } from "flowbite-react";
import { CalendarIcon } from "@radix-ui/react-icons";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

const Timeline = ({ transcripts, deleteTranscript }) => (
    <ol className="relative border-l border-gray-200">
        {transcripts.map((transcript, index) => (
            <li key={index} className="flex flex-col mb-10 ml-4 p-2 rounded-2xl border hover:bg-slate-100">
                <div className="absolute w-3 h-3 bg-black rounded-full mt-1.5 -left-1.5 border border-white"></div>

                <div className='p-2 flex'>
                    <a href={transcript.document} className="text-xl basis-1/2 font-semibold text-black">
                        {transcript.title}
                    </a>
                    <div className='flex w-full items-center justify-end'>
                        <Button variant="ghost" size="sm">
                            <a href={transcript.document} target='_blank' rel="noopener noreferrer">
                                <Eye className="h-4 w-4" />
                            </a>
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => deleteTranscript(transcript.title)}>
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    </div>
                </div>
            </li>
        ))}
    </ol>
);

const ProofTimeline = ({ proof, deleteDocument }) => (
    <ol className="relative border-l border-gray-200">
        {proof.map((item, index) => (
            <li key={index} className="flex flex-col mb-10 ml-4 p-2 rounded-2xl border hover:bg-slate-100">
                <div className="absolute w-3 h-3 bg-black rounded-full mt-1.5 -left-1.5 border border-white"></div>
                <div className="mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500">
                    <p>Given by {item.given_by} </p>
                </div>
                <div className='flex'>
                    <div className='p-2 flex flex-col gap-4'>
                        <a href={item.document} className="text-xl basis-1/2 font-semibold text-black">
                            {item.title}
                        </a>
                        <p className="text-gray-600 w-60 break-words whitespace-normal">
                            <strong>Description:</strong> {item.description || "No description provided"}
                        </p>
                    </div>
                    <div className='flex w-full items-center justify-end'>
                        <Button variant="ghost" size="sm">
                            <a href={item.document} target='_blank' rel="noopener noreferrer">
                                <Eye className="h-4 w-4" />
                            </a>
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => deleteDocument(item.title)}>
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    </div>
                </div>
            </li>
        ))}
    </ol>
);

export default function CaseDetails() {
    const [caseDesc, setCaseDesc] = useState('');
    const [proof, setProof] = useState([]);
    const [proofTitle, setProofTitle] = useState('');
    const [proofDesc, setProofDesc] = useState('');
    const [proofGivenBy, setProofGivenBy] = useState('');
    const [proofFile, setProofFile] = useState(null);

    const [transcript, setTranscript] = useState([]);
    const [date, setDate] = useState(); // Initialize with current date
    const [transcriptTitle, setTranscriptTitle] = useState('');
    const [transcriptFile, setTranscriptFile] = useState(null);

    const proofInputRef = useRef(null);
    const transcriptRef = useRef(null);

    const location = useLocation();
    const { caseid, caseTitle } = location.state || {};

    const navigate = useNavigate();

    useEffect(() => {
        const getCaseDetails = async () => {
            try {
                const response = await axios.get(`http://localhost:8000/cases/get_case/${caseid}`);
                setTranscript(response.data.transcript);
                setProof(response.data.proof);
                setCaseDesc(response.data.description);
            } catch (error) {
                console.error('Error fetching case details:', error);
            }
        };
        getCaseDetails();
    }, [caseid]);

    const [openModal, setOpenModal] = useState(false);
    const [openModal2, setOpenModal2] = useState(false);

    const triggerTranscriptInput = () => transcriptRef.current.click();
    const triggerProofInput = () => proofInputRef.current.click();

    const handleTranscriptChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const fileLink = URL.createObjectURL(file);
            setTranscriptFile(fileLink);
        }
    };

    const handleProofChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const fileLink = URL.createObjectURL(file);
            setProofFile(fileLink);
        }
    };

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        if (!date || !(date instanceof Date) || isNaN(date.getTime()) || !transcriptFile) {
            alert("Please fill in all fields before submitting.");
            return;
        }
        const newTranscript = { title: transcriptTitle, date: date.toISOString(), document: transcriptFile };
        setTranscript((prev) => [...prev, newTranscript]);
        try {
            const response = await axios.post(`http://localhost:8000/addTranscript`, newTranscript);
            console.log(response.data);
            setOpenModal(false);
            setDate(new Date()); // Reset to current date
            setTranscriptTitle('');
            setTranscriptFile(null);
        } catch (error) {
            console.error("Error submitting transcript:", error);
        }
    };

    const handleFormSubmit2 = async (e) => {
        e.preventDefault();
        const newProof = { title: proofTitle, description: proofDesc, given_by: proofGivenBy, document: proofFile };
        setProof((prev) => [...prev, newProof]);
        try {
            const response = await axios.post(`http://localhost:8000/addProof`, newProof);
            console.log(response.data);
            setOpenModal2(false);
            setProofTitle('');
            setProofDesc('');
            setProofGivenBy('');
            setProofFile(null);
        } catch (error) {
            console.error("Error submitting proof:", error);
        }
    };

    const deleteDocument = (docTitle) => {
        setProof((prevProofs) => prevProofs.filter((doc) => doc.title !== docTitle));
    };

    const deleteTranscript = (transcriptTitle) => {
        setTranscript((prevTranscripts) => prevTranscripts.filter((transcript) => transcript.title !== transcriptTitle));
    };

    return (
        <div className="overflow-auto container h-screen mx-auto p-4 space-y-6">
            <Card>
                <CardHeader className='flex sm:flex-row justify-between items-center'>
                    <CardTitle className='text-3xl'>{caseTitle}</CardTitle>
                    <Button onClick={() => {
                        navigate('caseChat', { state: { caseid, caseTitle } });
                    }} className="w-full py-2 px-8 max-sm:hidden sm:w-auto">
                        <FileText className="mr-2 h-4 w-4" /> AI Analyse
                    </Button>
                </CardHeader>
                <CardContent className='flex flex-col space-y-6'>
                    <p className='text-center sm:text-start text-gray-600'>{caseDesc}</p>
                </CardContent>
            </Card>

            <div className="grid lg:grid-cols-2 gap-6">
                <Card className='h-min'>
                    <CardHeader className='flex text-start flex-row justify-between items-center'>
                        <CardTitle className='text-xl text-start'>Case Transcripts</CardTitle>
                        <Button onClick={() => setOpenModal(true)} className="w-full py-2 px-8 max-sm:w-auto max-sm:px-4 sm:w-auto">
                            <Plus className="mr-2 h-4 w-4" /> Add Transcript
                        </Button>
                    </CardHeader>
                    <CardContent>
                        <ScrollArea className=" w-full pr-4">
                            <Timeline transcripts={transcript} deleteTranscript={deleteTranscript} />
                        </ScrollArea>
                    </CardContent>
                </Card>

                <Modal
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
                    dismissible show={openModal} size='2xl'
                    onClose={() => setOpenModal(false)}
                >
                    <Modal.Body>
                        <form onSubmit={handleFormSubmit}>
                            <div className="bg-white max-w-2xl space-y-6 flex flex-col font-montserrat text-center justify-center items-center">
                                <h1>Pick issue date</h1>
                                <Popover>
                                    <PopoverTrigger asChild>
                                        <Button
                                            variant={"outline"}
                                            className={cn(
                                                "w-[240px] justify-start text-left font-normal",
                                                !date && "text-muted-foreground"
                                            )}
                                        >
                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                            {date ? format(date, "PPP") : <span>Pick a date</span>}
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0" align="start">
                                        <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                                    </PopoverContent>
                                </Popover>
                                <label htmlFor='transcript-title'>Enter Transcript Title</label>
                                <Input id='transcript-title' type='text' onChange={(e) => setTranscriptTitle(e.target.value)} />
                                <input id='transcript-input' type='file' className='hidden' ref={transcriptRef} onChange={handleTranscriptChange} required />
                                <Button onClick={triggerTranscriptInput} className="w-full py-2 px-8 max-sm:w-auto max-sm:px-4 sm:w-auto">
                                    Upload transcript
                                </Button>
                                <Button type='submit' className="w-full py-2 px-8 max-sm:w-auto max-sm:px-4 sm:w-auto">
                                    Add Transcript
                                </Button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>

                <Card className='h-min'>
                    <CardHeader className='flex flex-row justify-between items-center'>
                        <CardTitle className='text-xl'>Proof</CardTitle>
                        <Button onClick={() => setOpenModal2(true)} className="w-full py-2 px-8 max-sm:w-auto max-sm:px-4 sm:w-auto">
                            <Plus className="mr-2 h-4 w-4" /> Add Proof
                        </Button>
                    </CardHeader>
                    <CardContent>
                        <ScrollArea className=" w-full pr-4">
                            <ProofTimeline proof={proof} deleteDocument={deleteDocument} />
                        </ScrollArea>
                    </CardContent>
                </Card>

                <Modal
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
                    dismissible show={openModal2} size='2xl'
                    onClose={() => setOpenModal2(false)}
                >
                    <Modal.Body>
                        <form onSubmit={handleFormSubmit2}>
                            <div className="bg-white max-w-2xl space-y-6 flex flex-col font-montserrat text-center justify-center items-center">
                                <label htmlFor='proof-title'>Enter Proof Title</label>
                                <Input id='proof-title' type='text' onChange={(e) => setProofTitle(e.target.value)} />
                                <label htmlFor='proof-description'>Enter Proof Description</label>
                                <Input id='proof-description' type='text' onChange={(e) => setProofDesc(e.target.value)} />
                                <label htmlFor='proof-given-by'>Proof Given By</label>
                                <Input id='proof-given-by' type='text' onChange={(e) => setProofGivenBy(e.target.value)} />
                                <input id='proof-input' type='file' className='hidden' ref={proofInputRef} onChange={handleProofChange} required />
                                <Button onClick={triggerProofInput} className="w-full py-2 px-8 max-sm:w-auto max-sm:px-4 sm:w-auto">
                                    Upload Proof
                                </Button>
                                <Button type='submit' className="w-full py-2 px-8 max-sm:w-auto max-sm:px-4 sm:w-auto">
                                    Add Proof
                                </Button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>
            </div>
        </div>
    );
}
