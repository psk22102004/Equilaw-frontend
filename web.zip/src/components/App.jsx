// App.jsx
import React, { useState } from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import HomePage from './HomePage';
import Login from './Login';
import Dashboard from './Dashboard';
import Chatbot from './Chatbot';
import DocGenerate from './DocGenerate';
import CaseDetails from './CaseDetails';
import NoSidebarLayout from './layouts/NoSidebarLayout';
import SidebarLayout from './layouts/SidebarLayout';
import { AddCaseForm } from './AddCaseForm';
import CaseChat from './CaseChat';
//import Dashboard2 from './Dashboard2';
import CaseDetails2 from './CaseDetails2';
import Dashboard2 from './Dashboard';
import Hearings from './HookWalaForm';
import HearingForm from './HearingForm';
import CaseDetails3 from './CaseDetails3';
import Dashboard3 from './Dashboard3';
import VectorCaseSearch from './VectorCaseSearch'
import ViewAll from './ViewAll';
import ViewAllc from './ViewAllc';
import Navbar from './HomePage Components/Navbar';
const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState(null);

  const router = createBrowserRouter([
    {
      path: '/',
      element: <NoSidebarLayout />,
      children: [
        {
          index: true,
          element: <HomePage />,
        },
        {
          path: 'login',
          element: <Login />, // Here after login navigate to /user/:id
        },
      ],
    },
    {
      path: '/user',
      element: <SidebarLayout />,

      children: [
        {
          index: true,
          element: <Dashboard3 />,
        },
        {
          path: 'home',
          element: <Dashboard3 />,
        },
        {
          path: 'AI',
          element: <Chatbot />,
        },
        {
          path: 'Doc',
          element: <DocGenerate />,

        },
        {
          path: 'addCase',
          element: <AddCaseForm />
        },
        {
          path: ':caseId',
          element: <CaseDetails3 />,
        },
        {
          path: ':caseId/caseChat',
          element: <CaseChat />,
        },
        {
          path: 'vectorSearch',

          element: <VectorCaseSearch />
        }, {
          path: 'viewAllopen',
          element: <ViewAll />
        },

      ],
    },
  ]);

  return (
    <RouterProvider router={router} />
  );
};

export default App;
