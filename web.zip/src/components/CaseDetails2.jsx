import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
import b64toBlob from 'b64-to-blob';
import b64Data from './TimepassFile'; //for example
import TranscriptProofBox from './TranscriptProofBox';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { Plus, FileText, Trash2, Eye } from 'lucide-react';
import { Modal } from "flowbite-react";
import { CalendarIcon } from "@radix-ui/react-icons";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

const CaseDetails2 = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const caseid = location.state; //extract case id for useEffect

    const [caseTitle, setCaseTitle] = useState("This is an example case title");
    const [caseIssueDate, setCaseIssueDate] = useState("22-10-2004");
    const [caseCategory, setcaseCategory] = useState("Land Issue");
    const [caseDesc, setCaseDesc] = useState("This is an example case description");

    const [caseProof, setCaseProof] = useState([
        { title: 'Proof no 1', description: 'this is some proof description', given_by: 'psk kadam', document: b64Data },
        { title: 'Proof no 2', description: 'this is some proof description', given_by: 'psk kadam', document: b64Data },
        { title: 'Proof no 3', description: 'this is some proof description', given_by: 'psk kadam', document: b64Data },
    ])


    const [caseTranscript, setCaseTranscript] = useState([
        { title: 'Transcript no 1', date: '22-10-2004', document: b64Data },
        { title: 'Transcript no 2', date: '22-10-2004', document: b64Data },
    ])

    const fetchCaseDetails = async () => {
        const response = await axios.get(`http://localhost:8000/cases/get_case/${caseid}`);
        //here response.data is an object containing caseid , title , issue_date , category , description , proof , transcript
        //proof contains : title , description , given_by , proof_text_full , document
        //transcript contains : title , date , transcript_text_summary , document
        setCaseTitle(response.data.title);
        setCaseIssueDate(response.data.issue_date);
        setcaseCategory(response.data.category);
        setCaseDesc(response.data.description);

        setCaseProof(
            (prev) => {
                return ([...prev, ...response.data.proof])
            }
        )
        setCaseTranscript(
            (prev) => {
                return ([...prev, ...response.data.transcript])
            }
        )

        // this should actually be setCaseProof(response.data.proof);
        //setCaseTranscript(response.data.transcript);

    }

    // Convert base64 string to Blob
    const base64ToBlob = (base64) => {
        const byteString = atob(base64.split(',')[1]);
        const mimeString = base64.split(',')[0].split(':')[1].split(';')[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ab], { type: mimeString });
    };


    // useEffect(
    //     () => {
    //         fetchCaseDetails();
    //     }, [caseid]
    // )



    return (
        <div className=" h-screen  ">
            <main className=" p-8 overflow-auto space-y-6 bg-elephant-50 text-black ">


                {/* CASE TITLE AND DESCRIPTION STARTS */}
                <div className='flex flex-col  rounded-xl p-6 space-y-6 bg-white border shadow-lg  border-elephant-950'>
                    <div className='flex justify-between items-center'>
                        <h1 className='text-3xl font-bold'>{caseTitle}</h1>
                        <button onClick={() => {
                            navigate('caseChat', { state: { caseid, caseTitle } });
                        }}
                            className='border border-black px-4 py-2 rounded-xl bg-elephant-800 font-bold text-white'>AI Analyse</button>
                    </div>
                    <p className='text-lg'>{caseDesc}</p>
                </div>
                {/* CASE TITLE AND DESCRIPTION ENDS */}

                {/* CASE TRANSCRIPT AND PROOF TABLE STARTS */}

                <div className='grid grid-cols-12 gap-6   '>
                    {/* CASE TRANSCRIPT TABLE STAR  STARTS */}
                    <TranscriptProofBox caseid={caseid} data={caseTranscript} fetchCaseDetails={fetchCaseDetails} />
                    {/* CASE TRANSCRIPT TABLE ENDS */}

                    {/* CASE PROOF TABLE STARTS */}
                    <TranscriptProofBox caseid={caseid} data={caseProof} fetchCaseDetails={fetchCaseDetails} />

                    {/* CASE PROOF TABLE ENDS */}
                </div>

                {/* CASE TRANSCRIPT AND PROOF TABLE ENDS */}
            </main>
        </div>
    )
}

export default CaseDetails2